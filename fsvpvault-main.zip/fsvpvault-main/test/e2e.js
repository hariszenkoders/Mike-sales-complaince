// End-to-end click test at phone width. Run with the server up: BASE=http://localhost:3123 EMAIL=... PASS=... node test/e2e.js
const { chromium } = require('playwright');
const BASE = process.env.BASE || 'http://localhost:3000';
const OUT = process.env.OUT || '.';
(async () => {
  const b = await chromium.launch();
  const pg = await b.newPage({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2 });
  const errs = []; pg.on('pageerror', e => errs.push('pageerror: ' + e.message)); pg.on('console', m => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errs.push('console: ' + m.text()); });
  const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) process.exitCode = 1; };
  const fill = async (name, v) => pg.fill('#fvForm [name="' + name + '"]', v);
  const save = async () => { await pg.click('#fvForm [data-formok]'); await pg.waitForTimeout(500); };
  const go = async (sel) => { await pg.click(sel); await pg.waitForTimeout(250); };

  await pg.goto(BASE + '/'); ok(/FSVP records/.test(await pg.textContent('h1')), 'landing page');
  await pg.screenshot({ path: OUT + '/01-landing.png' });
  await pg.goto(BASE + '/app'); ok(pg.url().indexOf('/login') > 0, 'app redirects to login');
  await pg.fill('#email', 'wrong@x.com'); await pg.fill('#password', 'nope'); await pg.click('button[type=submit]');
  ok(await pg.isVisible('.err'), 'bad password rejected');
  await pg.fill('#email', process.env.EMAIL); await pg.fill('#password', process.env.PASS); await pg.click('button[type=submit]');
  await pg.waitForURL(/\/app/); ok(true, 'logged in');
  ok(/Harbor Lane/.test(await pg.textContent('body')), 'demo workspace loads by default');
  await pg.screenshot({ path: OUT + '/02-overview.png' });

  // every screen renders
  for (const n of ['overview', 'suppliers', 'program', 'capa', 'records', 'help', 'billing']) { await go('#nav [data-go="' + n + '"]'); ok((await pg.textContent('#main')).length > 50, 'screen ' + n); }

  // add supplier
  await go('#nav [data-go="suppliers"]'); await go('[data-act="supplier_add"]');
  await fill('name', 'Test Noodle Co., Ltd.'); await fill('loc', 'Bangkok, Thailand'); await fill('foods', 'Rice noodles');
  await pg.check('#fvForm input[value="other"]'); await save();
  ok(/Test Noodle/.test(await pg.textContent('#main')), 'supplier added and opened');

  // supplier 0 actions
  await go('#nav [data-go="suppliers"]'); await go('#main [data-go="supplier"][data-sel="0"]');
  await go('[data-act="approve"]'); await fill('basis', 'E2E basis'); await save(); ok(/E2E basis|Approved/.test(await pg.textContent('#main')), 'approve');
  await go('[data-act="reeval"]'); await fill('conclusion', 'E2E reevaluation'); await save(); ok(!/Couldn/.test(await pg.textContent('#toast')) && /E2E reevaluation/.test(await pg.textContent('#main')), 'reeval');
  await go('[data-act="monitor_run"]'); await pg.waitForTimeout(3000); ok(/FDA check/i.test(await pg.textContent('#toast')), 'run check now');
  await go('[data-act="alerts"]'); await save(); ok(true, 'alert settings');
  await go('[data-act="req_settings"]'); await save(); ok(true, 'request settings');
  await go('[data-act="remind_all"]'); ok(true, 'remind all');
  await go('[data-act="profile"]'); await save(); ok(true, 'edit foods');
  if (await pg.$('[data-act="request"]')) { await go('[data-act="request"]'); ok(/Request (saved|emailed)/.test(await pg.textContent('#toast')), 'request from supplier'); }
  await go('[data-act="vrec_add"][data-type="test"]'); await fill('title', 'E2E sampling record'); await save();
  ok(/E2E sampling record/.test(await pg.textContent('#main')), 'verification record created');
  await go('[data-act="vrec_edit"]'); const f0 = await pg.$('#fvForm textarea'); await f0.fill('E2E field'); await save(); ok(/E2E field/.test(await pg.textContent('#main')), 'vrec edit');
  if (await pg.$('[data-sign]')) { await go('[data-sign]'); ok(/Signed by/.test(await pg.textContent('#main')), 'sign record'); }

  // upload
  await go('#nav [data-go="suppliers"]'); await go('#main [data-go="supplier"][data-sel="0"]');
  await go('[data-upload][data-target^="slot:0:process"]');
  await pg.setInputFiles('#upFile', { name: 'retort-records.pdf', mimeType: 'application/pdf', buffer: Buffer.from('%PDF-1.4 test') });
  await pg.check('#upNone'); await go('[data-saveupload]'); await pg.waitForTimeout(400);
  ok(/retort-records|Process records/.test(await pg.textContent('#main')) && await pg.$('a[href^="/api/file/"]'), 'upload saved with file link');
  const href = await pg.getAttribute('a[href^="/api/file/"]', 'href'); const r = await pg.request.get(BASE + href); ok(r.status() === 200, 'uploaded file downloads');

  // remove + reinstate supplier 1
  await go('#nav [data-go="suppliers"]'); await go('#main [data-go="supplier"][data-sel="1"]');
  await go('[data-go="remove"]'); await go('[data-confirmremove]'); ok(/Reinstate|removed/i.test(await pg.textContent('#main')), 'remove supplier');
  await go('[data-reinstate]'); ok(true, 'reinstate supplier');

  // program
  await go('#nav [data-go="program"]');
  await go('[data-act="identity"]'); await fill('email', 'fsvp@harborlane.example'); await fill('duns', '000000000'); await save();
  ok(/fsvp@harborlane.example/.test(await pg.textContent('#main')), 'importer identity');
  await go('[data-act="qi_add"]'); await fill('name', 'Second QI'); await save(); ok(true, 'add QI');
  await go('#main [data-proc]'); await go('[data-act="proc_edit"]'); await pg.fill('#fvForm textarea', 'Step one E2E\nStep two'); await save();
  ok(/Step one E2E/.test(await pg.textContent('#main')), 'procedure edited');
  await go('#nav [data-go="program"]'); await go('#main [data-go="scope"]'); await go('[data-act="scope_edit"]'); await save(); ok(true, 'scope edit');

  // capa
  await go('#nav [data-go="capa"]'); await go('[data-act="capa_add"][data-kind="complaint"]'); await fill('finding', 'E2E complaint'); await save();
  ok(/E2E complaint/.test(await pg.textContent('#main')), 'complaint logged');
  await go('[data-act="capa_close"]'); await fill('root', 'E2E root'); await save(); ok(/E2E root/.test(await pg.textContent('#main')), 'capa closed');

  // help, billing
  await go('#nav [data-go="help"]'); await go('[data-act="support"]'); await fill('msg', 'hello'); await save(); ok(/Message (saved|sent)/.test(await pg.textContent('#toast')), 'support');
  await go('#nav [data-go="billing"]'); await go('[data-act="nopay"]'); ok(/no payments/i.test(await pg.textContent('#toast')), 'billing message');

  // persistence after reload
  await pg.reload(); await go('#nav [data-go="capa"]'); ok(/E2E complaint/.test(await pg.textContent('#main')), 'data persists after reload');
  await pg.screenshot({ path: OUT + '/03-capa.png', fullPage: true });

  // import a private workspace file, if one is given
  if (process.env.PRIVATE_FILE) {
    await go('#nav [data-go="help"]'); await pg.setInputFiles('#impFile', process.env.PRIVATE_FILE); await pg.click('[data-act="import"]');
    await pg.waitForURL(/ws=/); ok(true, 'private workspace imported'); await pg.goto(BASE + '/app?ws=demo');
  }
  // switch workspace
  const opts = await pg.$$eval('#wsSel option', o => o.map(x => x.value));
  if (opts.length > 1) { await pg.selectOption('#wsSel', opts[1]); await pg.waitForURL(/ws=/); ok(true, 'workspace switch to ' + opts[1]); await pg.screenshot({ path: OUT + '/04-other-ws.png' }); }
  // reset demo
  await pg.goto(BASE + '/app?ws=demo'); await go('#nav [data-go="help"]'); await go('[data-act="reset"]'); await pg.click('#fvForm [data-formok]'); await pg.waitForTimeout(1200);
  await go('#nav [data-go="capa"]'); ok(!/E2E complaint/.test(await pg.textContent('#main')), 'reset demo data');
  // horizontal overflow check
  for (const n of ['overview', 'suppliers', 'program', 'capa']) { await go('#nav [data-go="' + n + '"]'); const w = await pg.evaluate(() => document.documentElement.scrollWidth); ok(w <= 392, 'no sideways scroll on ' + n + ' (' + w + ')'); }
  // supplier upload page (public, no login)
  const sp = await b.newPage({ viewport: { width: 390, height: 844 } });
  await sp.goto(BASE + '/upload'); await sp.fill('#code', 'WRONG-CODE'); await sp.click('#go'); await sp.waitForTimeout(400);
  ok(await sp.isVisible('#m1'), 'supplier upload: bad code rejected');
  await sp.fill('#code', 'hlf-siam-4k2p'); await sp.click('#go'); await sp.waitForTimeout(500);
  ok(/Siam Coast/.test(await sp.textContent('#who')), 'supplier upload: code finds supplier');
  await sp.selectOption('#doc', 'process'); await sp.setInputFiles('#file', { name: 'retort-lot-14.pdf', mimeType: 'application/pdf', buffer: Buffer.from('%PDF-1.4 x') });
  await sp.check('#noexp'); await sp.fill('#from', 'QA Manager, qa@siam.example'); await sp.fill('#title', 'Retort records lot 14'); await sp.click('#send'); await sp.waitForTimeout(700);
  ok(/Sent:/.test(await sp.textContent('#m2')), 'supplier upload: file sent');
  await sp.setInputFiles('#file', { name: 'bad.html', mimeType: 'text/html', buffer: Buffer.from('<script>') }); await sp.check('#noexp'); await sp.click('#send'); await sp.waitForTimeout(500);
  ok(/isn.t accepted/.test(await sp.textContent('#m2')), 'supplier upload: html rejected');
  await sp.close();
  await pg.goto(BASE + '/app?ws=demo'); ok(/Review document from Siam Coast/.test(await pg.textContent('#main')), 'supplier upload shows on overview');
  await go('#nav [data-go="suppliers"]'); await go('#main [data-go="supplier"][data-sel="0"]'); ok(/Retort records lot 14/.test(await pg.textContent('#main')) && /To review/.test(await pg.textContent('#main')), 'supplier upload waits for review');
  await go('[data-act="file_reject"]'); await fill('reason', 'Wrong lot, please send lot 14'); await save();
  ok(/Rejected: Wrong lot/.test(await pg.textContent('#main')), 'reject shows reason');
  const sp2 = await b.newPage({ viewport: { width: 390, height: 844 } }); await sp2.goto(BASE + '/upload?code=HLF-SIAM-4K2P'); await sp2.waitForTimeout(600);
  ok(/Not accepted.*Wrong lot/s.test(await sp2.textContent('#fb')), 'supplier sees rejection reason via link'); await sp2.close();
  await pg.click('a[href="/logout"]'); await pg.waitForURL(BASE + '/'); ok(true, 'logout');
  ok(!errs.length, 'no page errors' + (errs.length ? ': ' + errs.join(' | ') : ''));
  await b.close();
})().catch(e => { console.error('CRASH', e.message); process.exit(1); });

// Tests for the November features. Run with the server up: BASE=... EMAIL=... PASS=... PRIVATE_FILE=... FIXTURES=dir node test/features.js
const { chromium } = require('playwright');
const fs = require('fs');
const BASE = process.env.BASE, FX = process.env.FIXTURES, OUT = process.env.OUT || '.';
const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) process.exitCode = 1; };
(async () => {
  const b = await chromium.launch(); const pg = await b.newPage({ viewport: { width: 390, height: 844 } });
  const errs = []; pg.on('pageerror', e => errs.push(e.message));
  await pg.route(/fonts\.googleapis/, r => r.abort());
  const go = async (sel) => { await pg.click(sel); await pg.waitForTimeout(300); };
  const fill = (n, v) => pg.fill('#fvForm [name="' + n + '"]', v);
  const save = async () => { await pg.click('#fvForm [data-formok]'); await pg.waitForTimeout(600); };
  await pg.goto(BASE + '/login'); await pg.fill('#email', process.env.EMAIL); await pg.fill('#password', process.env.PASS); await pg.click('button[type=submit]'); await pg.waitForURL(/app/);
  if (process.env.PRIVATE_FILE) { await go('#nav [data-go="help"]'); await pg.setInputFiles('#impFile', process.env.PRIVATE_FILE); await pg.click('[data-act="import"]'); await pg.waitForURL(/ws=/); }

  // ---- certificate reading ----
  await go('#nav [data-go="suppliers"]'); await go('#main [data-go="supplier"][data-sel="0"]');
  await go('[data-upload][data-target="slot:0:gfsi"]');
  await pg.setInputFiles('#upFile', FX + '/cert_std.pdf'); await go('[data-saveupload]'); await pg.waitForTimeout(800);
  ok(/Expiry read from the file: 2028-03-13/.test(await pg.textContent('#toast')), 'expiry read from uploaded PDF');
  ok(/Read from file: FSSC 22000 v6, by SGS/.test(await pg.textContent('#main')), 'standard and body shown under file');
  await go('[data-upload][data-target="slot:0:gfsi"]');
  await pg.setInputFiles('#upFile', FX + '/sqf.pdf'); await go('[data-saveupload]'); await pg.waitForTimeout(800);
  ok(/wasn.t found in this file/.test(await pg.textContent('#main')), 'wrong-supplier certificate flagged');

  // ---- shipments (demo workspace) ----
  await pg.goto(BASE + '/app?ws=demo'); await go('#nav [data-go="ships"]');
  await go('[data-act="ship_import"]'); await pg.setInputFiles('#csvPick', FX + '/entries.csv'); await save(); await pg.waitForTimeout(500);
  ok(/3 shipment\(s\) imported/.test(await pg.textContent('#toast')), 'CSV import');
  ok(/1 shipment\(s\) aren.t matched/.test(await pg.textContent('#main')), 'unmatched supplier flagged');
  ok(/Process records missing/.test(await pg.textContent('#main')), 'low-acid lot needs process records');
  await go('[data-target$=":coa"]'); await pg.setInputFiles('#upFile', FX + '/cert_std.pdf'); await pg.check('#upNone'); await go('[data-saveupload]'); await pg.waitForTimeout(700);
  ok(/COA: /.test(await pg.textContent('#main')), 'COA attached to shipment');
  const firstEdit = await pg.$('[data-act="ship_edit"]'); await firstEdit.click(); await pg.waitForTimeout(200);
  await pg.selectOption('#fvForm [name=sup]', '0'); await save(); ok(!/aren.t matched/.test(await pg.textContent('#main')), 'supplier picked for unmatched shipment');
  await pg.selectOption('#shipSup', '2'); await pg.waitForTimeout(200); ok((await pg.$$('[data-act="ship_edit"]')).length === 1, 'filter by supplier');
  await pg.screenshot({ path: OUT + '/ships.png', fullPage: true });

  // ---- FDA records package ----
  await pg.goto(BASE + '/app?ws=demo'); await go('#nav [data-go="records"]'); await go('[data-act="pkg_scope"]');
  const [dl] = await Promise.all([pg.waitForEvent('download', { timeout: 30000 }), pg.click('[data-act="package_zip"]')]);
  const zpath = OUT + '/package.zip'; await dl.saveAs(zpath);
  const z = require(process.env.APPDIR + '/lib/zip.js').read(fs.readFileSync(zpath)); const names = z.map(function (f) { return f.name; });
  console.log(names.join('\n'));
  ok(names.indexOf('0-INDEX.html') === 0, 'package has index');
  ok(names.filter(function (n) { return /^1-plans\//.test(n); }).length === 3, 'package has a plan per active supplier');
  ok(names.some(function (n) { return /5-shipments\/.*coa-/.test(n); }), 'package includes lot COA files');
  ok(names.some(function (n) { return /history\.csv$/.test(n); }), 'package includes history');

  // ---- to-do list ----
  await pg.goto(BASE + '/app?ws=demo'); await pg.waitForTimeout(300);
  ok(/To do/.test(await pg.textContent('#main')) && /This week|Overdue/.test(await pg.textContent('#main')), 'overview shows grouped to-do list');
  const firstTask = await pg.$eval('[data-act="todo_done"]', function (b) { return b.getAttribute('data-label'); });
  await go('[data-act="todo_done"]'); await pg.waitForTimeout(300);
  ok(/Done \(1\)/.test(await pg.textContent('#main')), 'task marked done: ' + firstTask);
  await pg.click('summary:has-text("Done (1)")'); await go('[data-act="todo_done"][data-undo]'); ok(!/Done \(1\)/.test(await pg.textContent('#main')), 'undo done');

  // ---- expiry calendar and export ----
  await go('[data-go="expiry"]'); ok(/Expiry calendar/.test(await pg.textContent('#main')), 'expiry calendar opens');
  const r = await pg.request.get(BASE + '/api/export/expiry?ws=demo'); const t = await r.text();
  ok(r.status() === 200 && /Supplier,Document,Expires/.test(t), 'expiry CSV export');

  // ---- supplier CSV import ----
  await go('#nav [data-go="suppliers"]'); await go('[data-act="sup_import"]'); await pg.setInputFiles('#csvPick', FX + '/suppliers.csv'); await save(); await pg.waitForTimeout(500);
  ok(/1 supplier\(s\) added, 1 already in the list/.test(await pg.textContent('#toast')), 'supplier CSV import');
  // ---- document ZIP import ----
  await go('[data-act="docs_import"]'); await pg.setInputFiles('#csvPick', FX + '/docs.zip'); await pg.click('#fvForm [data-formok]'); await pg.waitForTimeout(2500);
  const imp = await pg.textContent('#fvForm');
  ok(/2 document\(s\) filed, 1 not filed/.test(imp), 'ZIP import filed 2, skipped 1');
  ok(/COA lot GL-55.pdf → Golden Lotus Sauce Co., Ltd. · coa/.test(imp), 'COA sorted by file name');
  await pg.click('#fvForm [data-formok]');

  // ---- plan archive and what changed ----
  await go('#nav [data-go="suppliers"]'); await go('#main [data-go="supplier"][data-sel="2"]'); await go('[data-go="plan"]');
  await go('[data-act="plan_sign"]'); if (await pg.$('#fvForm')) await save(); await pg.waitForTimeout(500);
  ok(/Signed plan versions \(1\)/.test(await pg.textContent('#main')), 'signed plan saved as version');
  await go('[data-go="plan"]'); await pg.click('#planDoc .ph'); await pg.fill('#fvForm textarea[name=value]', 'Sold to food service distributors'); await save();
  await go('[data-act="plan_diff_now"]'); await pg.waitForTimeout(800);
  ok(/Added:.*Sold to food service distributors/s.test(await pg.textContent('#fvForm')), 'what changed since signing shows the new text');
  await pg.click('#fvForm [data-formok]');
  await go('[data-act="plan_sign"]'); if (await pg.$('#fvForm')) await save(); await pg.waitForTimeout(500);
  await go('summary:has-text("Signed plan versions")'); await go('[data-act="plan_diff"]'); await pg.waitForTimeout(800);
  ok(/Sold to food service distributors/.test(await pg.textContent('#fvForm')), 'diff between signed versions');
  await pg.click('#fvForm [data-formok]');
  await pg.waitForTimeout(500); ok(/Signed the FSVP plan/.test(await pg.textContent('#histBox')), 'supplier history shows plan signing');

  ok(!errs.length, 'no page errors ' + errs.join(' | '));
  await b.close();
})().catch(e => { console.error('CRASH', e.message); process.exit(1); });

const { chromium } = require('playwright');
const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) process.exitCode = 1; };
(async()=>{const b=await chromium.launch();const pg=await b.newPage({viewport:{width:1280,height:900}});
const errs=[]; pg.on('pageerror',e=>errs.push(e.message));
await pg.route(/fonts\.googleapis/, r=>r.abort());
const B=process.env.BASE;
await pg.goto(B+'/login');await pg.fill('#email','demo@fsvpvault.com');await pg.fill('#password','test-pass-123');await pg.click('button[type=submit]');await pg.waitForURL(/app/);
await pg.click('#nav [data-go="help"]'); await pg.setInputFiles('#impFile',process.env.PRIVATE_FILE); await pg.click('[data-act="import"]'); await pg.waitForURL(/ws=bluemonkey/);
await pg.evaluate(()=>{}); await pg.click('#nav [data-go="suppliers"]'); await pg.click('#main [data-go="supplier"][data-sel="0"]');
await pg.click('[data-go="plan"]'); await pg.waitForTimeout(300);
const n0 = await pg.$$eval('#planDoc .ph', x=>x.length); ok(n0>10, 'plan shows '+n0+' highlighted fields');
ok(await pg.isVisible('#pfList'), 'open-fields list shown');
await pg.click('#pfList summary'); const items = await pg.$$eval('#pfList li', x=>x.map(l=>l.innerText.replace(/\n/g,' | ')).slice(0,6)); console.log(items.join('\n'));
// click an inline highlighted field: intended use
const iu = await pg.$('#planDoc .ph:has-text("CONFIRM INTENDED USE")'); await iu.click(); await pg.waitForTimeout(200);
ok(await pg.isVisible('#fvForm'), 'clicking a field opens the editor');
await pg.fill('#fvForm textarea[name=value]', 'Sold to retail grocery for direct consumption'); await pg.click('#fvForm [data-formok]'); await pg.waitForTimeout(600);
ok(/Sold to retail grocery/.test(await pg.textContent('#planDoc')), 'value appears in plan');
const n1 = await pg.$$eval('#planDoc .ph', x=>x.length); ok(n1===n0-1, 'open count dropped to '+n1);
// list link for DUNS → related link to importer profile
await pg.click('#pfList summary').catch(()=>{}); 
const d = await pg.$('[data-pfopen*="DUNS"]'); if (!(await d.isVisible())) await pg.click('#pfList summary'); await d.click(); await pg.waitForTimeout(200);
ok(/Importer profile/.test(await pg.textContent('#fvForm')), 'DUNS editor offers importer profile link');
await pg.click('#fvForm [data-act="identity"]'); await pg.waitForTimeout(200);
ok(/Importer profile/.test(await pg.textContent('#fvForm h2')), 'related link opens importer profile form');
await pg.fill('#fvForm [name=duns]','123456789'); await pg.click('#fvForm [data-formok]'); await pg.waitForTimeout(600);
await pg.click('#nav [data-go="suppliers"]'); await pg.click('#main [data-go="supplier"][data-sel="0"]'); await pg.click('[data-go="plan"]'); await pg.waitForTimeout(300);
ok(/123456789/.test(await pg.textContent('#planDoc')) && !/ENTER DUNS NUMBER/.test(await pg.textContent('#planDoc')), 'DUNS from profile fills both plan spots');
// edit filled field again, then clear
await pg.click('#planDoc .pf'); await pg.fill('#fvForm textarea[name=value]', ''); await pg.click('#fvForm [data-formok]'); await pg.waitForTimeout(600);
ok(/CONFIRM INTENDED USE/.test(await pg.textContent('#planDoc')), 'clearing puts the placeholder back');
await pg.reload(); await pg.click('#nav [data-go="suppliers"]'); await pg.click('#main [data-go="supplier"][data-sel="0"]'); await pg.click('[data-go="plan"]'); await pg.waitForTimeout(300);
// sign with open fields warns
await pg.click('[data-act="plan_sign"]'); await pg.waitForTimeout(200); ok(/still open/.test(await pg.textContent('#fvForm')), 'signing with open fields warns first');
await pg.click('#fvForm [data-formcancel]');
await pg.screenshot({path:(process.env.OUT||'.')+'/plan-edit.png'});
await pg.setViewportSize({width:390,height:844}); await pg.click('#planDoc .ph'); await pg.waitForTimeout(200); await pg.screenshot({path:(process.env.OUT||'.')+'/plan-edit-phone.png'});
ok(!errs.length, 'no page errors '+errs.join('|'));
await b.close();})();

// Email flow test. Needs the server running with SMTP settings pointed at a test mail server.
const { chromium } = require('playwright');
const BASE = process.env.BASE; const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) process.exitCode = 1; };
(async () => {
  const b = await chromium.launch(); const pg = await b.newPage({ viewport: { width: 390, height: 844 } });
  await pg.route(/fonts\.googleapis/, r => r.abort());
  await pg.goto(BASE + '/login'); await pg.fill('#email', process.env.EMAIL); await pg.fill('#password', process.env.PASS); await pg.click('button[type=submit]'); await pg.waitForURL(/app/);
  const go = async (sel) => { await pg.click(sel); await pg.waitForTimeout(300); };
  await go('#nav [data-go="suppliers"]'); await go('#main [data-go="supplier"][data-sel="0"]');
  ok(/No email address yet/.test(await pg.textContent('#main')), 'supplier without contact is flagged');
  await go('[data-act="request"]'); ok(/Add the supplier.s email address/.test(await pg.textContent('#toast')), 'request without contact explains why not sent');
  await go('[data-act="supplier_contact"]'); await pg.fill('#fvForm [name=name]', 'Khun Somchai'); await pg.fill('#fvForm [name=emails]', 'qa@siam.example'); await pg.click('#fvForm [data-formok]'); await pg.waitForTimeout(500);
  ok(/qa@siam.example/.test(await pg.textContent('#main')), 'contact saved');
  await go('[data-act="remind_all"]'); await pg.waitForTimeout(500); ok(/Reminder emailed to qa@siam.example/.test(await pg.textContent('#toast')), 'reminder emailed');
  await go('#nav [data-go="help"]'); await pg.waitForTimeout(1200);
  ok(/Email is set up/.test(await pg.textContent('#mailBox')) && /sent/.test(await pg.textContent('#mailBox')), 'email log shows sent');
  await go('[data-act="mail_test"]'); await pg.waitForTimeout(800); ok(/Test email sent/.test(await pg.textContent('#toast')), 'test email');
  await b.close();
})();

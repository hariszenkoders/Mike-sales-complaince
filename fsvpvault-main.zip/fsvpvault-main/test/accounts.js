// Accounts, roles, 2-step sign-in, reset and backup. Server must run with AUTO_MAIL=off and no SMTP (links are shown instead).
const { chromium } = require('playwright');
const auth = require(process.env.APPDIR + '/lib/auth.js');
const BASE = process.env.BASE; const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) process.exitCode = 1; };
(async () => {
  const b = await chromium.launch();
  const owner = await b.newPage({ viewport: { width: 390, height: 844 } }); await owner.route(/fonts\.googleapis/, r => r.abort());
  const errs = []; owner.on('pageerror', e => errs.push(e.message));
  const login = async (pg, email, pw) => { await pg.goto(BASE + '/login'); await pg.fill('#email', email); await pg.fill('#password', pw); await pg.click('button[type=submit]'); await pg.waitForLoadState(); };
  const go = async (pg, sel) => { await pg.click(sel); await pg.waitForTimeout(400); };
  await login(owner, process.env.EMAIL, process.env.PASS); ok(/\/app/.test(owner.url()), 'owner signs in');
  if (process.env.PRIVATE_FILE) { await go(owner, '#nav [data-go="help"]'); await owner.setInputFiles('#impFile', process.env.PRIVATE_FILE); await owner.click('[data-act="import"]'); await owner.waitForURL(/ws=/); }
  await go(owner, '#nav [data-go="account"]'); await owner.waitForTimeout(500);
  ok(/Team/.test(await owner.textContent('#main')), 'owner sees team');

  // invite a staff member limited to the demo workspace
  await go(owner, '[data-act="user_invite"]'); await owner.fill('#fvForm [name=name]', 'Sam Staff'); await owner.fill('#fvForm [name=email]', 'sam@example.com');
  await owner.selectOption('#fvForm [name=role]', 'staff'); await owner.uncheck('#fvForm input[value="*"]'); await owner.check('#fvForm input[value="demo"]'); await owner.click('#fvForm [data-formok]'); await owner.waitForTimeout(700);
  const link = (await owner.textContent('#fvForm .mono')).trim(); ok(/\/reset\?t=/.test(link), 'invite link shown when email is off');
  await owner.click('#fvForm [data-formok]');
  const staff = await b.newPage({ viewport: { width: 390, height: 844 } }); await staff.route(/fonts\.googleapis/, r => r.abort());
  await staff.goto(link.replace('https://fsvpvault.com', BASE)); await staff.fill('#pw', 'password1234'); await staff.fill('#pw2', 'password1234'); await staff.click('button[type=submit]');
  ok(/too easy/.test(await staff.textContent('body')), 'weak password rejected');
  await staff.fill('#pw', 'staff-pass-12345'); await staff.fill('#pw2', 'staff-pass-12345'); await staff.click('button[type=submit]');
  ok(/Password saved/.test(await staff.textContent('body')), 'invited user sets password');
  await login(staff, 'sam@example.com', 'staff-pass-12345'); ok(/\/app/.test(staff.url()), 'staff signs in');
  const opts = await staff.$$eval('#wsSel option', o => o.map(x => x.value)); ok(opts.length === 1 && opts[0] === 'demo', 'staff sees only the demo workspace');
  let r = await staff.request.post(BASE + '/api/action', { data: { ws: 'bluemonkey', type: 'support', p: { msg: 'x' } } }); ok(r.status() === 404, 'staff blocked from other workspace');
  r = await staff.request.post(BASE + '/api/action', { data: { ws: 'demo', type: 'approve', p: { sup: 0, mode: 'ok' } } }); ok(r.status() === 403, 'staff cannot approve (QI only)');
  r = await staff.request.post(BASE + '/api/action', { data: { ws: 'demo', type: 'supplier_contact', p: { sup: 0, emails: 'qa@x.com' } } }); ok(r.status() === 200, 'staff can edit');
  r = await staff.request.get(BASE + '/api/backup'); ok(r.status() === 403, 'staff cannot download backup');

  // owner makes staff view-only; old session is cut off and new one is read-only
  await go(owner, '#nav [data-go="account"]'); await owner.waitForTimeout(500);
  const edits = await owner.$$('[data-act="user_edit"]'); await edits[edits.length - 1].click(); await owner.waitForTimeout(200);
  await owner.selectOption('#fvForm [name=role]', 'viewer'); await owner.click('#fvForm [data-formok]'); await owner.waitForTimeout(600);
  r = await staff.request.post(BASE + '/api/action', { data: { ws: 'demo', type: 'supplier_contact', p: { sup: 0, emails: 'qa@x.com' } } }); ok(r.status() === 401, 'role change signs the user out (' + r.status() + ')');
  await login(staff, 'sam@example.com', 'staff-pass-12345');
  r = await staff.request.post(BASE + '/api/action', { data: { ws: 'demo', type: 'supplier_contact', p: { sup: 0, emails: 'qa@x.com' } } }); ok(r.status() === 403, 'viewer cannot change records');
  await go(staff, '#nav [data-go="suppliers"]'); ok(!(await staff.isVisible('[data-act="supplier_add"]')), 'viewer does not see edit buttons');

  // owner turns on 2-step sign-in
  await go(owner, '#nav [data-go="account"]'); await owner.waitForTimeout(500); await go(owner, '[data-act="totp_on"]');
  const secret = (await owner.textContent('#fvForm .mono')).replace(/\s/g, '');
  await owner.fill('#fvForm [name=code]', '000000'); await owner.click('#fvForm [data-formok]'); await owner.waitForTimeout(500);
  ok(/didn.t work/.test(await owner.textContent('#toast')), 'wrong code rejected');
  await go(owner, '[data-act="totp_on"]'); const secret2 = (await owner.textContent('#fvForm .mono')).replace(/\s/g, '');
  await owner.fill('#fvForm [name=code]', auth.totpCode(secret2)); await owner.click('#fvForm [data-formok]'); await owner.waitForTimeout(700);
  ok(/2-step sign-in is on/.test(await owner.textContent('#main')), '2-step turned on');
  const o2 = await b.newPage(); await login(o2, process.env.EMAIL, process.env.PASS); ok(/\/login\/code/.test(o2.url()), 'sign-in asks for code');
  await o2.fill('#code', '123456'); await o2.click('button[type=submit]'); ok(/didn.t work/.test(await o2.textContent('body')), 'bad code at sign-in rejected');
  await o2.fill('#code', auth.totpCode(secret2)); await o2.click('button[type=submit]'); await o2.waitForLoadState(); ok(/\/app/.test(o2.url()), 'code completes sign-in');

  // forgot password page doesn't reveal accounts
  const f = await b.newPage(); await f.goto(BASE + '/forgot'); await f.fill('#email', 'nobody@nowhere.com'); await f.click('button[type=submit]');
  ok(/If an account exists/.test(await f.textContent('body')), 'forgot page is neutral');
  // backup
  r = await o2.request.get(BASE + '/api/backup'); const buf = await r.body();
  const names = require(process.env.APPDIR + '/lib/zip.js').read(buf).map(x => x.name); ok(names.indexOf('fsvpvault.db') >= 0 && names.some(n => /^seeds\//.test(n)), 'backup has database and seeds');
  // legal pages
  r = await f.request.get(BASE + '/privacy'); ok(r.status() === 200 && /Privacy policy/.test(await r.text()), 'privacy page');
  r = await f.request.get(BASE + '/terms'); ok(r.status() === 200 && /Terms of use/.test(await r.text()), 'terms page');
  ok(!errs.length, 'no page errors ' + errs.join(' | '));
  await b.close();
})().catch(e => { console.error('CRASH', e.message); process.exit(1); });
